package com.example.springsecurityapplication.enumm;

public enum Role {
    ROLE_ADMIN,
    ROLE_USER
}
